// nav
const toggleClass = (className, elementId, elementsRemoveClass = false) => {
    if(elementsRemoveClass){
        elementsRemoveClass.forEach(element => {
            document.getElementById(element).classList.remove(className);
        });
    }

    document.getElementById(elementId).classList.toggle(className);
}

const removeClass = (className, elementId) => {
    document.getElementById(elementId).classList.remove(className);
}

// contact form
const setPickedPlan = (plan) => {
    document.getElementById('picked-plan').value = plan;
}

const contactForm = document.getElementById('contactForm');
const formMessage = document.getElementById('formMessage');
const formButton = document.getElementById('formButton');

if(contactForm){
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
    
        formButton.disabled = true;
        formMessage.className = '';
        
        const input = new FormData(e.target);
    
        const email = input.get('email') || false;
        const phone = input.get('phone') || false;
    
        if(!email || !phone){
            formMessage.textContent = 'Please fill all form inputs.';
            formMessage.classList.add('negative', 'active');
            return formButton.disabled = false;
        }
    
        if(!email.match(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)){
            formMessage.textContent = 'Please enter a valid email address.';
            formMessage.classList.add('negative', 'active');
            return formButton.disabled = false;
        }
    
        try{
            let request = new XMLHttpRequest();
        
            request.open("POST", "/assets/php/send-email.php", true);
            
            request.onreadystatechange = () => {
                if(request.readyState == 4 && request.status == 200){
                    if(JSON.parse(request.responseText).success){
                        formMessage.textContent = 'We\'ve Received your request and get back to you soon.';
                        return formMessage.classList.add('positive', 'active');
                    }
                }
            }
            
            request.send(input);
        }catch(e){
            formMessage.textContent = 'There was a problem sending your request, Please try again later.';
            formMessage.classList.add('active');
            return formButton.disabled = false;
        }
    });
}

// plans
const setPrices = async () => {
    const oneMonth = document.getElementById('oneMonth');
    const sixMonth = document.getElementById('sixMonth');
    const oneYear = document.getElementById('oneYear');

    var plansPricesUSD = {
        '1-month': 10,
        '6-month': 30,
        '1-year': 60
    }

    var currency = Intl.NumberFormat('en-us', {
        currency: 'USD',
        style: 'currency',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });

    try{
        let userLocale = await fetch('https://ipapi.co/json/');
        userLocale = await userLocale.json() || false;

        let currencyRate = await fetch('https://openexchangerates.org/api/latest.json?app_id=0e66e9ba03a1420094928a90ccaf4a20');
        currencyRate = await currencyRate.json() || false;

        if(!userLocale.currency || !currencyRate.rates[userLocale.currency]){
            throw new Error('123');
        }

        plansPricesUSD = {
            '1-month': 10 * currencyRate.rates[userLocale.currency],
            '6-month': 30 * currencyRate.rates[userLocale.currency],
            '1-year': 60 * currencyRate.rates[userLocale.currency]
        }
    
        currency = Intl.NumberFormat(undefined, {
            currency: userLocale.currency,
            style: 'currency',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        });
    }catch(e){
        
    }finally{
        oneMonth.textContent = currency.format(plansPricesUSD["1-month"]);
        sixMonth.textContent = currency.format(plansPricesUSD["6-month"]);
        oneYear.textContent = currency.format(plansPricesUSD["1-year"]);
    }
}