<?php
// header('Content-type: application/json');

require './PHPMailer.php';
require './SMTP.php';
require './Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer(false);

try {
    $pickedPlan = $_POST['picked-plan'] ?: false;
    $email = $_POST['email'] ?: false;
    $phone = $_POST['phone'] ?: false;

    if(!$pickedPlan || !$email || !$phone){
        throw new Exception('Missing Input.');
    }

    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_OFF;
    $mail->isSMTP();
    $mail->Host       = 'premium184.web-hosting.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'hi@prime-iptv.cc';
    $mail->Password   = 'pr^5a6v36or$';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port       = 465;

    //Recipients
    $mail->setFrom('hi@prime-iptv.cc', 'Prime IPTV');
    $mail->addAddress('iptv2077@hotmail.com');
    $mail->addReplyTo($email);

    //Content
    $mail->isHTML(true);
    $mail->Subject = 'Email from Prime IPTV';
    $mail->Body    = "
        <h1><b>Email from Prime IPTV</b></h1>
        <h2><u><b>Request Details</b></u></h2>
        <p><b>Plan: </b>$pickedPlan</p>
        <p><b>Email: </b>$email</p>
        <p><b>Phone: </b>$phone</p>
    ";
    $mail->AltBody = "Email from Prime IPTV. Plan: $pickedPlan , Email: $email , Phone: $phone .";

    $mail->send();
    echo json_encode(['success' => true]);
}catch(Exception $e){
    echo json_encode(['success' => false]);
}